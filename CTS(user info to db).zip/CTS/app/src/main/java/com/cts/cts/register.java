package com.cts.cts;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity {
    private Button saveuser;
    private EditText name;
    private EditText email;
    private EditText phonenumber;
    private EditText city;
    private EditText password;
    private TextView alreadysignin;
    private ImageView Profile;
    String savename,saveemail,savephonenumber,savecity,savepassword;

      private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        saveuser=(Button)findViewById(R.id.BTSave);
        name=(EditText)findViewById(R.id.NameET);
        email=(EditText)findViewById(R.id.EmailET);
        phonenumber=(EditText)findViewById(R.id.phonenoET);
        city=(EditText)findViewById(R.id.cityET);
        password=(EditText)findViewById(R.id.passwordET);
        alreadysignin=(TextView)findViewById(R.id.TValreadysignup);
        firebaseAuth=FirebaseAuth.getInstance();
        Profile=(ImageView)findViewById(R.id.IVprofile);



        saveuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                save();


                if(save())
                {
                  //Authentication details to FireBase Console
                    String useremail=email.getText().toString().trim();
                    String userpassword=password.getText().toString().trim();
                    firebaseAuth.createUserWithEmailAndPassword(useremail,userpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                sendEmailVerification();
                                register();
                            }
                            else
                            {
                                Toast.makeText(register.this,"Registration unsuccessful",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });



            }
            }

        });

        alreadysignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                Intent signin=new Intent(register.this,login.class);
                startActivity(signin);
            }
        });
    }
                 public Boolean save()
                 {
                     Boolean result=false;
                       savename=name.getText().toString();
                       saveemail=email.getText().toString();
                      savephonenumber=phonenumber.getText().toString();
                      savecity=city.getText().toString();
                      savepassword = password.getText().toString();

                     if((savename.equals("")||saveemail.equals("")||savephonenumber.equals("")||savecity.equals("")||savepassword.equals("")))
                     {
                         Toast.makeText(this,"Please enter all the details",Toast.LENGTH_SHORT).show();
                     }
                     else
                     {
                         result=true;
                     }
                     return result;
                 }
private  void sendEmailVerification()
{
    FirebaseUser firebaseUser=firebaseAuth.getCurrentUser();
    if(firebaseUser!=null)
    {
        firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if(task.isSuccessful())
                {

                    Toast.makeText(register.this,"Verification Mail is Sent To Your Mail_Id ",Toast.LENGTH_SHORT).show();
                     firebaseAuth.signOut();
                     finish();
                     Intent nee=new Intent(register.this,login.class);
                     startActivity(nee);
                }
                else
                {
                    Toast.makeText(register.this ,"Verification Of Your Mail_Id Is Not Successful",Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}
private void register()
{
    FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
    DatabaseReference myRef=firebaseDatabase.getReference(firebaseAuth.getCurrentUser().getUid());
    UserProfile userProfile=new UserProfile(savename,saveemail,savephonenumber,savecity);
    myRef.setValue(userProfile);
}

}



