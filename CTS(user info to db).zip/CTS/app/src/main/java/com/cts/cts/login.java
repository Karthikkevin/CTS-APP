package com.cts.cts;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.logging.LogRecord;

public class login extends AppCompatActivity {

    private EditText email;
    private EditText password;
    private FirebaseAuth firebaseAuth;
    ProgressDialog progressDialog;
private TextView forgotpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = (EditText) findViewById(R.id.EmailET);
        password = (EditText) findViewById(R.id.PasswordET);
        final Button login = (Button) findViewById(R.id.BTSignin);
        forgotpassword = (TextView) findViewById(R.id.TVforgotpassword);

        TextView newuser = (TextView) findViewById(R.id.TVnewuser);
        firebaseAuth = FirebaseAuth.getInstance();
FirebaseUser user=firebaseAuth.getCurrentUser();
if(user!=null)
{
    finish();
    Intent indent=new Intent(login.this,dashboard.class);
    startActivity(indent);
}


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String  bemail=email.getText().toString();
            String bpassword=password.getText().toString();

            if((bemail.equals(""))||(bpassword.equals("")))
            {
                Toast.makeText(login.this,"ENTER THE EMAIL_ID AND PASSWORD FOR SIGN IN",Toast.LENGTH_SHORT).show();

            }

               if(bemail.equals(""))
            {
                Toast.makeText(login.this,"ENTER THE EMAIL_ID FOR SIGN IN",Toast.LENGTH_SHORT).show();

            }
            else if(bpassword.equals(""))
            {
                Toast.makeText(login.this,"ENTER THE PASSWORD FOR SIGN IN",Toast.LENGTH_SHORT).show();
            }
            else {
                    progressDialog =new ProgressDialog(login.this);
                   progressDialog.setMessage("Welcome to Crop Tuterly System App ");

                   progressDialog.show();
                   validate(bemail, bpassword);
            }
            }
        });
forgotpassword.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent next=new Intent(login.this,ForgetPassword.class);
        startActivity(next);
    }
});

        newuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent register = new Intent(login.this, register.class);
                startActivity(register);
            }
        });

    }

    private void validate(String bemail, String bpassword) {

        firebaseAuth.signInWithEmailAndPassword(bemail, bpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {

                    progressDialog.dismiss();
                    checkEmailVerification();
                } else {
                     progressDialog.dismiss();
                    Toast.makeText(login.this, "Login failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

        private void checkEmailVerification()
    {
        FirebaseUser firebaseUser=firebaseAuth.getInstance().getCurrentUser();
        Boolean emailflag=firebaseUser.isEmailVerified();

        if(emailflag)
        {   Toast.makeText(login.this,"VERIFICATION SUCCESSFUL",Toast.LENGTH_LONG).show();
            finish();
            Intent next=new Intent(login.this,dashboard.class);
            startActivity(next);
        }
        else
        {
            Toast.makeText(login.this,"VERIFY THE EMAIL_ID",Toast.LENGTH_SHORT).show();
            firebaseAuth.signOut();
        }
    }
    }

