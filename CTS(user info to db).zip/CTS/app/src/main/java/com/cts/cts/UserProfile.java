package com.cts.cts;

import android.database.StaleDataException;

/**
 * Created by hi on 3/24/2018.
 */

public class UserProfile {
    public String farmer_name;
    public String farmer_email;
    public String farmer_phonenumber;
    public String farmer_city;

    public UserProfile(String farmer_name, String farmer_email, String farmer_phonenumber, String farmer_city) {
        this.farmer_name = farmer_name;
        this.farmer_email = farmer_email;
        this.farmer_phonenumber = farmer_phonenumber;
        this.farmer_city = farmer_city;
    }
}
